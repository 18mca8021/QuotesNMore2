package com.example.quotesmore;

import android.content.Intent;
import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.view.MenuInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageButton;

import java.util.ArrayList;

import static com.example.quotesmore.R.id.toolbarbtn;

public class ScrollingActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArrayList<RecyclerData> recyclerDataArrayList;
    ImageButton imageButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrolling);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        recyclerView = findViewById(R.id.idCourseRV);

        imageButton = findViewById(R.id.toolbarbtn);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                moveTaskToBack(true);
            }
        });

        recyclerDataArrayList = new ArrayList<>();

        recyclerDataArrayList.add(new RecyclerData("inspiration", R.drawable.p));
        recyclerDataArrayList.add(new RecyclerData("Love", R.drawable.p));
        recyclerDataArrayList.add(new RecyclerData("Motivation", R.drawable.p));
        recyclerDataArrayList.add(new RecyclerData("Artistic", R.drawable.p));
        recyclerDataArrayList.add(new RecyclerData("Truth", R.drawable.p));
        recyclerDataArrayList.add(new RecyclerData("Myth", R.drawable.p));
        recyclerDataArrayList.add(new RecyclerData("Funny", R.drawable.p));
        recyclerDataArrayList.add(new RecyclerData("Saying", R.drawable.p));
        recyclerDataArrayList.add(new RecyclerData("Slogan", R.drawable.p));
        recyclerDataArrayList.add(new RecyclerData("Sad", R.drawable.p));


        RecyclerViewAdapter adapter = new RecyclerViewAdapter(recyclerDataArrayList, this);
        StaggeredGridLayoutManager staggeredGridLayoutManager = new StaggeredGridLayoutManager(2, LinearLayoutManager.VERTICAL);

        recyclerView.setLayoutManager(staggeredGridLayoutManager);
        recyclerView.setAdapter(adapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_scrolling, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.settings:
                Intent intent = new Intent(this, Settings.class);
                this.startActivity(intent);
                return true;
            case R.id.logout:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }

    public void gotoactivity(View view) {

        Intent intent = new Intent(ScrollingActivity.this,MainActivity.class);
        startActivity(intent);
    }

}