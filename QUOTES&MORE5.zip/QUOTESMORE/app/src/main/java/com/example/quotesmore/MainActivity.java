package com.example.quotesmore;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;
    Button button;
    Drawable drawable;
    Bitmap bitmap;
    String ImagePath;
    Uri uri;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



    }

    public void btnsharefn(View view) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT,"Time is money. Time-saver is millionaire.");
        view.getContext().startActivity(Intent.createChooser(share,"Share Text"));
    }
    public void btnsharefn2(View view) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT,"Life is a puzzle that a person needs to be solved.");
        view.getContext().startActivity(Intent.createChooser(share,"Share Text"));
    }
    public void btnsharefn3(View view) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT,"More mistakes.More learnings.More succeed.");
        view.getContext().startActivity(Intent.createChooser(share,"Share Text"));
    }
    public void btnsharefn4(View view) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT,"Don't feel depressed. Listen music and stay relaxed.");
        view.getContext().startActivity(Intent.createChooser(share,"Share Text"));
    }

    public void btnsharefn5(View view) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT,"Positive people make positive vibes. Positive vibes make positive surroundings. Positive surroundings give positive results.");
        view.getContext().startActivity(Intent.createChooser(share,"Share Text"));
    }

}
